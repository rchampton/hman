var app=require('express')();
var http=require('http').Server(app);
var io=require('socket.io')(http);

var gameIds=[];

app.get('/', function(rq, rs){
	rs.sendFile(__dirname+'/index.htm');
});

app.get('/js/:name', function(rq, rs){
    var jsUri=__dirname+'/'+rq.params.name;
    rs.sendFile(jsUri);
});

io.on('connection', function(socket){
	console.log('A user connected and was given id ' + socket.id);
    var forLater=socket.id;

    socket.on('login', function(data){
        console.log('login with data ' + data );
    });
    
    socket.on('disconnect', function(socket){
		console.log('A user with socket id ' + forLater + ' disconnected');
	});
});

http.listen(3000, function(){
    console.log('Listening on *:3000');
});