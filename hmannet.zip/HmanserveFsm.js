var HmanserveFsm=machina.Fsm.extend({
    DEBUGTRACE: true

    // Machina interface
    , initialize: function(socket){
        this._socket=socket;
        console.log('Connected with socket ' + this._socket);
        this.handle('start');
    }
    , initialState: "uninitialized"
    , states:{
        uninitialized: {
            "*": function(){
                // this.transition('disconnected');
                this.transition('matching');
            }
        }
        , matching: {
            _onEnter: function(){
                this._players.length=0;
            }
            , matched: function(){
            }
        }
        , setup: {
            _onEnter: function(){}
            , play: function(){}
        }
        , playing: {
            _onEnter: function(){}
            , gameover: function(){}
        }
        , done: {
        }
    }

    // Private members
    , _playerTurn: 0
    , _players: []      // [ Jesse, Samuel ]
    , _words: []        // [ buffalo, watermellon ]
    , _letters: []      // [ [a,b,c,...], [b,d,g,...] ]
    , _masks: []        // [ --ffa--, -a-e--ll-- ]

    // Private methods

    // Public API
    , help: function(){
        var transs=[];
        for(var p in this.states[this.state]){
            if(this.states[this.state].hasOwnProperty(p))
                transs.push(p);
        }
        if(this.DEBUGTRACE&&p.length>0){
            console.debug('Available transitions');
            console.debug('\t'+transs.join('\n\t'));
        }
    }
    , havePlayers: function(){return (this._players.length==2);}
    , playersReady: function(){return (this._words.length==2);}
});